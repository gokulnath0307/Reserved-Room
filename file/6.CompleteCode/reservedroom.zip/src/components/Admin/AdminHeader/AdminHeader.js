import React from 'react'
import '../Admin.css'

export default function AdminHeader() {
    return (
        <div>
            <div className='Header'>
                <p className='text-center'>
                    RVS CAS
                    <p>
                    Computer Science Department Reserved Room
                </p>
                </p>
        </div>
       
        </div>
    )
}
